🏠 [Начало (Библиотека БД)](README.md) | ⏩ [Глава 01. Основи, Типове и Видове БД](01-00-SQL-INTRO-AND-CRUD.md)

---

# 00-01. Архитектура на СУБД, Инструменти, Бекъпи и Миграции

**Цел:** Как работи сървърът на базата данни под капака (системни бази `master`, `model`, `msdb`, `tempdb`), кои инструменти използваме всеки ден (SSMS, pgAdmin, DBeaver, Docker) и как се правят сигурни резервни копия (Backups) и миграции на данни.

## Съдържание на темата
* [1. Системните бази данни в MS SQL Server и PostgreSQL](#1-системните-бази-данни-в-ms-sql-server-и-postgresql)
* [2. Ежедневни инструменти и стартиране в Docker](#2-ежедневни-инструменти-и-стартиране-в-docker)
* [3. Бекъпи и Възстановяване (Backup & Restore)](#3-бекъпи-и-възстановяване-backup--restore)
* [4. Миграции и Пренос на схеми и данни (Generate Scripts vs EF Migrations)](#4-миграции-и-пренос-на-схеми-и-данни)
* [5. Чести грешки, Капани и Как да ги избегнем](#5-чести-грешки-капани-и-как-да-ги-избегнем)

---

## 1. СИСТЕМНИТЕ БАЗИ ДАННИ В MS SQL SERVER И POSTGRESQL

Когато инсталираш сървър за бази данни, той автоматично създава няколко системни бази, които управляват работата му:

| Системна база | СУБД | За какво отговаря? | Какво се случва, ако се повреди или напълни? |
| :--- | :--- | :--- | :--- |
| **`master`** | MS SQL Server | Пази конфигурацията на целия сървър, потребителските логини и списъка с всички бази. | **Сървърът изобщо не може да стартира!** |
| **`model`** | MS SQL Server | Шаблон (Template), от който се копират настройките при всяко `CREATE DATABASE`. | Новите бази не могат да се създават. |
| **`msdb`** | MS SQL Server | Пази историята на бекъпите и автоматичните задачи (SQL Server Agent Jobs). | Спират планираните нощни бекъпи и автоматизации. |
| **`tempdb`** | MS SQL Server | Временна работна памет на диска за `#Temp` таблици, сортиране (`ORDER BY`) и `RCSI` версии. | Базата забива при големи заявки (изчиства се при рестарт). |
| **`postgres` / `template1`** | PostgreSQL | `postgres` е системната база по подразбиране; `template1` е шаблонът за нови бази. | Загуба на административен достъп по подразбиране. |

---

## 2. ЕЖЕДНЕВНИ ИНСТРУМЕНТИ И СТАРТИРАНЕ В DOCKER

### Графични клиенти (GUI Tools):
* **SSMS (SQL Server Management Studio):** Официалният стандартен инструмент за MS SQL Server под Windows (най-добър за Execution Plans, бекъпи и администриране).
* **pgAdmin 4:** Официалният уеб/десктоп инструмент за PostgreSQL.
* **DBeaver / DataGrip:** Универсални клиенти — свързват се едновременно към MS SQL, PostgreSQL, MySQL, SQLite, MongoDB и Redis от един прозорец.
* **MongoDB Compass / Redis Insight:** Официалните визуални инструменти за преглед на документи в MongoDB и ключове в Redis.

### Стартиране на бази данни за 10 секунди с Docker (без инсталация в Windows):
```bash
# 1. PostgreSQL в Docker контейнер:
docker run --name my-postgres -e POSTGRES_PASSWORD=StrongPassword123 -p 5432:5432 -d postgres:16

# 2. Redis в Docker контейнер:
docker run --name my-redis -p 6379:6379 -d redis:7

# 3. MongoDB в Docker контейнер:
docker run --name my-mongo -p 27017:27017 -d mongo:7
```

---

## 3. БЕКЪПИ И ВЪЗСТАНОВЯВАНЕ (BACKUP & RESTORE)

Видовете бекъпи в продукция следват стратегията **3-2-1** (3 копия на данните, на 2 различни носителя, 1 извън офиса/облака):

* **Full Backup (Пълен бекъп):** Копира цялата база данни в един `.bak` файл. Бавен, но съдържа всичко.
* **Differential Backup (Диференциален бекъп):** Записва **само промените от последния Full Backup насам** (много по-бърз и малък).
* **Transaction Log Backup:** Записва промените на всеки 5–15 минути и позволява **Point-in-Time Recovery** (възстановяване на базата до конкретна секунда преди някой да изтрие таблица по грешка!).

```sql
-- ============================================================
-- BACKUP И RESTORE В MS SQL SERVER (T-SQL)
-- ============================================================

-- 1. Създаване на пълен компресиран бекъп:
BACKUP DATABASE ShopDb
TO DISK = 'C:\Backups\ShopDb_2026_11_08.bak'
WITH COMPRESSION, STATS = 10;

-- 2. Възстановяване на базата от .bak файл:
RESTORE DATABASE ShopDb
FROM DISK = 'C:\Backups\ShopDb_2026_11_08.bak'
WITH REPLACE;
```

```bash
# ============================================================
# BACKUP И RESTORE В POSTGRESQL (КОНЗОЛА)
# ============================================================
pg_dump -U postgres -F c -f shopdb_backup.dump ShopDb
pg_restore -U postgres -d ShopDb_New -c shopdb_backup.dump
```

---

## 4. МИГРАЦИИ И ПРЕНОС НА СХЕМИ И ДАННИ

Как прехвърляме структурата на таблиците от компютъра на програмиста към реалния сървър?

1. **EF Core Migrations (Code-First стандарт в C#):**
   * Променяш C# класовете ➔ изпълняваш `dotnet ef migrations add AddOrdersTable` ➔ генерира се C# файл с точните промени (`Up` и `Down`), който се качва в Git и се изпълнява автоматично при деплой.
2. **Generate Scripts (в SSMS):**
   * Десен клик върху базата ➔ *Tasks ➔ Generate Scripts* ➔ можеш да избереш *Schema Only* (само `CREATE TABLE`) или *Schema and Data* (таблиците + `INSERT` заявките за данните). Използва се за прехвърляне на малки бази или учебни проекти.
3. **Database-First / DACPAC (SQL Server Data Tools):**
   * Сравнява две бази (*Schema Compare*) и автоматично генерира `ALTER TABLE` скрипт за синхронизация.

 **МИГРАЦИИ И ПРЕНОС НА СХЕМИ И ДАННИ (PMC, .NET CLI И SQL СКРИПТОВЕ)**

В реалната практика с C# и бази данни има **4 основни начина** за създаване, промяна и пренос на схемата между компютъра на разработчика и сървъра:

### А. Сравнение на командите в Visual Studio (Package Manager Console) срещу .NET CLI (Терминал)

| Действие | Visual Studio (NuGet / Package Manager Console) | Терминал / VS Code / Mac / Linux (.NET CLI) | Какво прави? |
| :--- | :--- | :--- | :--- |
| **Създаване на миграция** | `Add-Migration InitialCreate` | `dotnet ef migrations add InitialCreate` | Сравнява C# класовете със стария модел и генерира файл с промените. |
| **Прилагане към базата** | `Update-Database` | `dotnet ef database update` | Изпълнява чакащите миграции върху реалната SQL база. |
| **Връщане към стара версия** | `Update-Database PreviousMigrationName` | `dotnet ef database update PreviousMigrationName` | Изпълнява метода `Down()` и връща базата в предишното състояние. |
| **Изтриване на последната** | `Remove-Migration` | `dotnet ef migrations remove` | Изтрива последната миграция (само ако **още не е** приложена в БД!). |
| **SQL скрипт за продукция** | `Script-Migration -Idempotent` | `dotnet ef migrations script --idempotent` | Генерира чист `.sql` файл с `IF NOT EXISTS` проверки за DBA администратора. |
| **Database-First (Reverse Engineer)** | `Scaffold-DbContext "Server=..." Microsoft.EntityFrameworkCore.SqlServer -OutputDir Models` | `dotnet ef dbcontext scaffold "Server=..." Microsoft.EntityFrameworkCore.SqlServer -o Models` | Генерира C# Entity класове и `DbContext` от **вече съществуваща** SQL база! |

> **Важно за Package Manager Console (PMC) във Visual Studio:**
> * Изисква инсталиран NuGet пакет **`Microsoft.EntityFrameworkCore.Tools`**.
> * Ако в Solution-а имаш няколко проекта (напр. `WebApi`, `Data`, `Services`), в падащото меню **Default project** горе в конзолата **задължително избери проекта, в който се намира `DbContext`** (иначе ще получиш грешка *No DbContext was found*).

### Б. Алтернативни начини без EF Core (Database-First и DevOps инструменти)
1. **Generate Scripts (в SSMS):**
   * Десен клик върху базата ➔ *Tasks ➔ Generate Scripts* ➔ можеш да избереш *Schema Only* (само `CREATE TABLE`) или *Schema and Data* (таблиците + `INSERT` заявките за данните). Използва се за прехвърляне на малки бази или учебни проекти.
2. **DACPAC / Schema Compare (Visual Studio SQL Server Data Tools):**
   * Сравнява две бази данни визуално и автоматично генерира `ALTER TABLE` скрипт за синхронизация.
3. **Migration-Based SQL инструменти (`FluentMigrator`, `DbUp`, `Flyway`, `Liquibase`):**
   * Използват се в големи екипи (или с **Dapper**), където разработчиците пишат чисти `.sql` файлове (`001_CreateUsers.sql`, `002_AddOrders.sql`), а библиотеката пази таблица с историята на изпълнените скриптове.

---

## 5. ЧЕСТИ ГРЕШКИ, КАПАНИ И КАК ДА ГИ ИЗБЕГНЕМ

### Грешка 1: Бекъп, който никога не е тестван с `RESTORE`
* **Какво се случва:** Системата прави нощни `.bak` файлове в продължение на година, но при авария се оказва, че файлът е повреден или с грешни права и не може да се възстанови.
* **Как да избегнеш:** Бекъпът не съществува, докато не си го тествал с `RESTORE` върху тестови сървър!

### Грешка 2: Записване на собствени таблици вътре в системната база `master`
* **Какво се случва:** Отваряш SSMS и без да избереш `USE ShopDb;`, пускаш `CREATE TABLE Users ...`. Таблиците се създават вътре в системната база `master`, обърквайки конфигурацията на сървъра.
* **Как да избегнеш:** Винаги започвай SQL скриптовете си с изрично `USE MyDatabaseName;` на първия ред.

### Грешка 3: Ръчно пипане на колони в продукционната база без миграция в Git
* **Какво се случва:** Добавяш ръчно колона `Discount` директно в продукционната база, но забравяш да я добавиш в EF Core миграциите. Следващият деплой или нов колега в екипа получава грешки при стартиране.
* **Как да избегнеш:** Всяка промяна по схемата на базата минава през **Migrations** в Git, за да има пълна история кой, кога и защо е променил структурата.

---
🏠 [Начало (Библиотека БД)](README.md) | ⏩ [Глава 01. Основи, Типове и Видове БД](01-00-SQL-INTRO-AND-CRUD.md)

© 2026 Dev-Library / Бази данни: Архитектура на СУБД, Инструменти и Бекъпи
