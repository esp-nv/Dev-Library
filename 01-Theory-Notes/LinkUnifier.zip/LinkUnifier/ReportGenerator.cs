using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;

namespace LinkUnifier;

public static class ReportGenerator
{
    private static readonly Encoding Utf8NoBom = new UTF8Encoding(false);

    public static void WriteAllReports(FolderNode rootTree, AuditStats stats, string reportsDir)
    {
        Directory.CreateDirectory(reportsDir);
        string ts = DateTime.Now.ToString("dddd, yyyy-MM-dd HH:mm:ss", new CultureInfo("bg-BG"));

        var emptyDirs = new List<string>();
        TreeScanner.CollectEmptyNodes(rootTree, emptyDirs);

        var inProgressList = stats.RejectedLog.Where(r => r.Contains("В ПРОЦЕС")).ToList();

        int brokenLinks = stats.LastAuditIssues.Count(i => !i.IsAnchorOnly);
        int brokenAnchors = stats.LastAuditIssues.Count(i => i.IsAnchorOnly);

        // 1. Общо резюме с разделени цифри за линкове и #anchor котви
        var summary = new StringBuilder();
        summary.AppendLine("================================================================================");
        summary.AppendLine($"ОБЩО ОДИТНО РЕЗЮМЕ ОТ LINKUNIFIER — {ts}");
        summary.AppendLine("================================================================================");
        summary.AppendLine($"• Дърво и таблица на библиотеката:       reports/00-library-tree-map.md ({rootTree.SubFolders.Count} домейна)");
        summary.AppendLine($"• Преименувани *-Syntax.md файлове:       {stats.RenamedSyntaxFiles}");
        summary.AppendLine($"• Създадени липсващи README.md:          {stats.CreatedReadmes}");
        summary.AppendLine($"• Синхронизирани Navbar/Footer файлове:   {stats.UpdatedNavFiles}  -> виж 07-navbar-footer-sync.txt");
        summary.AppendLine($"• Одобрени и приложени поправки:          {stats.ApprovedLog.Count}  -> виж 02-approved-links.txt");
        summary.AppendLine($"• Изтрити остарели редове:               {stats.DeletedLinesLog.Count}  -> виж 03-deleted-lines.txt");
        summary.AppendLine($"• Одит — 1/ Счупени линкове:             {brokenLinks}  -> виж 04-grouped-audit-report.txt");
        summary.AppendLine($"• Одит — 2/ Невалидни #anchor котви:     {brokenAnchors}  -> виж 04-grouped-audit-report.txt");
        summary.AppendLine($"• Одит — ОБЩО проблеми (линкове+котви):  {stats.LastAuditIssues.Count}  -> виж 04-grouped-audit-report.txt");
        summary.AppendLine($"• Празни папки от DFS обхождането:        {emptyDirs.Count}  -> виж 05-empty-folders.txt");
        summary.AppendLine($"• CRUD операции по файлове/папки:         {stats.CrudLog.Count}  -> виж 06-crud-changes.txt");
        summary.AppendLine($"• Маркирани 'в процес / за добавяне':    {inProgressList.Count}  -> виж 08-in-progress-to-create.txt");
        File.WriteAllText(Path.Combine(reportsDir, "01-summary-report.txt"), summary.ToString(), Utf8NoBom);

        // 2. Одобрени и приложени промени
        WriteSectionFile(
            Path.Combine(reportsDir, "02-approved-links.txt"),
            $"ОДОБРЕНИ И ПРИЛОЖЕНИ ПРОМЕНИ ({stats.ApprovedLog.Count}) — {ts}",
            stats.ApprovedLog,
            "Няма одобрени промени при това пускане.");

        // 3. Изтрити остарели редове
        WriteSectionFile(
            Path.Combine(reportsDir, "03-deleted-lines.txt"),
            $"ИЗТРИТИ ОСТАРЕЛИ РЕДОВЕ ({stats.DeletedLinesLog.Count}) — {ts}",
            stats.DeletedLinesLog,
            "Няма изтрити редове при това пускане.");

        // 4. Групиран одит по файл: 1/ линкове; 2/ #anchor + номер на ред
        var groupedAudit = new StringBuilder();
        groupedAudit.AppendLine("================================================================================");
        groupedAudit.AppendLine($"ГРУПИРАН ОДИТ ПО ФАЙЛ (1/ ЛИНКОВЕ: {brokenLinks} | 2/ #ANCHOR: {brokenAnchors} | ОБЩО: {stats.LastAuditIssues.Count}) — {ts}");
        groupedAudit.AppendLine("================================================================================");
        if (stats.LastAuditIssues.Count == 0)
        {
            groupedAudit.AppendLine("🎉 Няма открити счупени линкове или невалидни котви!");
        }
        else
        {
            foreach (var fg in stats.LastAuditIssues.GroupBy(i => i.RelativeFile))
            {
                groupedAudit.AppendLine();
                groupedAudit.AppendLine($"📄 {fg.Key}:");
                var links = fg.Where(x => !x.IsAnchorOnly).ToList();
                var anchors = fg.Where(x => x.IsAnchorOnly).ToList();

                if (links.Count > 0)
                {
                    groupedAudit.AppendLine($"   1/ Линкове ({links.Count}):");
                    foreach (var l in links)
                        groupedAudit.AppendLine($"      • [#{l.Id}] ред {l.LineNumber}: {l.OriginalLink}  (Предложено: {l.ProposedReplacement})");
                }
                if (anchors.Count > 0)
                {
                    groupedAudit.AppendLine($"   2/ #anchor котви ({anchors.Count}):");
                    foreach (var a in anchors)
                        groupedAudit.AppendLine($"      • [#{a.Id}] ред {a.LineNumber}: {a.OriginalLink}  (Предложено: {a.ProposedReplacement})");
                }
            }
        }
        File.WriteAllText(Path.Combine(reportsDir, "04-grouped-audit-report.txt"), groupedAudit.ToString(), Utf8NoBom);

        // 5. Празни папки
        WriteSectionFile(
            Path.Combine(reportsDir, "05-empty-folders.txt"),
            $"ПРАЗНИ ПАПКИ ОТ POST-ORDER DFS ОБХОЖДАНЕТО ({emptyDirs.Count}) — {ts}",
            emptyDirs.Select(d => $"📂 {d}"),
            "🎉 Няма празни директории в библиотеката!");

        // 6. CRUD промени
        WriteSectionFile(
            Path.Combine(reportsDir, "06-crud-changes.txt"),
            $"CRUD ОПЕРАЦИИ ПО ФАЙЛОВЕ И ПАПКИ ({stats.CrudLog.Count}) — {ts}",
            stats.CrudLog,
            "Няма извършени CRUD операции при това пускане.");

        // 7. Navbar & Footer синхронизация
        WriteSectionFile(
            Path.Combine(reportsDir, "07-navbar-footer-sync.txt"),
            $"СИНХРОНИЗИРАНИ NAVBAR И FOOTER ФАЙЛОВЕ ({stats.NavSyncLog.Count}) — {ts}",
            stats.NavSyncLog,
            "Няма променени Navbar/Footer файлове (всички са актуални).");

        // 8. В процес / за добавяне
        WriteSectionFile(
            Path.Combine(reportsDir, "08-in-progress-to-create.txt"),
            $"МАРКИРАНИ В ПРОЦЕС / ЗА ДОБАВЯНЕ ({inProgressList.Count}) — {ts}",
            inProgressList,
            "Няма маркирани елементи 'в процес / за добавяне'.");
    }

    private static void WriteSectionFile(string path, string header, IEnumerable<string> lines, string emptyMsg)
    {
        var sb = new StringBuilder();
        sb.AppendLine("================================================================================");
        sb.AppendLine(header);
        sb.AppendLine("================================================================================");
        var list = lines.ToList();
        if (list.Count == 0)
            sb.AppendLine(emptyMsg);
        else
            foreach (var l in list) sb.AppendLine(l);

        File.WriteAllText(path, sb.ToString(), Utf8NoBom);
    }
}
